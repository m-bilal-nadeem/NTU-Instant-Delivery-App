import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:ntu_instant_delievery/Agroover%20screens/chatroom_page.dart';
import 'package:ntu_instant_delievery/Chat_Screens/login_screen.dart';
import 'package:ntu_instant_delievery/Models/ChatRoomModel.dart';
import 'package:ntu_instant_delievery/Models/UserModel.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:uuid/uuid.dart';
import '../widgets/UIHelper.dart';
import 'About.dart';
import 'Login_Screen.dart';
import 'Terms.dart';
import 'modeSelectionScreen.dart';

class OrderPage extends StatefulWidget {
  final bool isGuest; // New parameter to track guest status
  final UserModel userModel;
  final User firebaseuser;
  
  const OrderPage({
    super.key,
    this.isGuest = false,
    required this.userModel,
    required this.firebaseuser,
  });

  @override
  _OrderPageState createState() => _OrderPageState();
}

class _OrderPageState extends State<OrderPage> {
  final _nameController = TextEditingController();
  final _orderController = TextEditingController();
  final _locationController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  final String vendorNumber = "+923114594563";
  
  ChatRoomModel? chatRoom;
  var uuid = Uuid();

  // Fetch existing or create new chat room
  Future<ChatRoomModel?> getchatRoomModel(UserModel targetUser) async {
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection("chatrooms")
        .where("participants.${widget.userModel.uid}", isEqualTo: true)
        .where("participants.${targetUser.uid}", isEqualTo: true)
        .get();

    if (querySnapshot.docs.isNotEmpty) {
      var docData = querySnapshot.docs[0].data();
      ChatRoomModel existingChatRoom = ChatRoomModel.fromMap(docData as Map<String, dynamic>);
      chatRoom = existingChatRoom;
    } else {
      ChatRoomModel newChatRoom = ChatRoomModel(
        chatroomid: uuid.v1(),
        participants: {
          widget.userModel.uid!: true,
          targetUser.uid!: true,
        },
        lastMessage: "",
      );
      await FirebaseFirestore.instance.collection("chatrooms").doc(newChatRoom.chatroomid).set(newChatRoom.toMap());
      chatRoom = newChatRoom;
      UIHelper.ShowSnackBar(context, "New Chat Room Created Successfully");
    }
    return chatRoom;
  }

  Future<UserModel?> fetchUserById(String uid) async {
    try {
      DocumentSnapshot userDoc = await FirebaseFirestore.instance.collection("users").doc(uid).get();
      if (userDoc.exists) {
        return UserModel.fromMap(userDoc.data() as Map<String, dynamic>);
      } else {
        UIHelper.errordialoag(context, "User not found with UID: $uid");
        return null;
      }
    } catch (e) {
      UIHelper.errordialoag(context, "Error fetching user: $e");
      return null;
    }
  }

  void _sendOrderAndNavigateToChat() async {
    if (!_formKey.currentState!.validate()) return;

    // Construct message
    final message = '''
👋 *Hi there!* 

🧍‍♂️ *Name:* ${_nameController.text.trim()}
📍 *Location:* ${_locationController.text.trim()}
🛒 *Order Details:* ${_orderController.text.trim()}

❓Can you deliver this to my location?

Thanks! 😊
''';

    UserModel? adminModel = await fetchUserById("LAs9ktWonMXpHcGpWiJu4MDx9XL2");
    if (adminModel != null) {
      await getchatRoomModel(adminModel);
      // Optionally navigate to chat screen here
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ChatRoomPage(
            userModel: widget.userModel,
            targetUser: adminModel,
            chatRoom: chatRoom!,
            firebaseuser: widget.firebaseuser,
          ),
        ),
      );
    } else {
      UIHelper.errordialoag(context, "Admin user not found.");
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isSmallScreen = screenWidth < 360;

    return Scaffold(
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.green),
              child: FutureBuilder<User?>(
                future: Future.value(FirebaseAuth.instance.currentUser),
                builder: (context, snapshot) {
                  final user = snapshot.data;

                  return Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      CircleAvatar(
                        radius: 30,
                        backgroundColor: Colors.white,
                        backgroundImage: user?.photoURL != null
                            ? NetworkImage(user!.photoURL!)
                            : null,
                        child: user?.photoURL == null
                            ? Icon(
                                Icons.person,
                                size: 35,
                                color: Colors.green,
                              )
                            : null,
                      ),
                      SizedBox(height: 12),
                      Text(
                        user != null ? (user.displayName ?? "NTU User") : "NTU Delivery Menu",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                      if (user != null && user.email != null)
                        Text(
                          user.email!,
                          style: TextStyle(fontSize: 13, color: Colors.white70),
                        ),
                      if (widget.isGuest)
                        Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: TextButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (_) => LoginPage()),
                              );
                            },
                            child: Text(
                              "Login / Sign Up",
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        ),
                    ],
                  );
                },
              ),
            ),
            ListTile(
              leading: Icon(Icons.info_outline),
              title: Text("About"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => AboutUsPage(isDarkTheme: false)),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.library_books),
              title: Text("Terms & Conditions"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => TermsPage(isDarkTheme: false)),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.login),
              title: Text("Login another account"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.refresh),
              title: Text("Refresh App"),
              onTap: () {
                _formKey.currentState?.reset();
                _nameController.clear();
                _orderController.clear();
                _locationController.clear();
                Navigator.pop(context);
                UIHelper.ShowSnackBar(context, "App Refreshed Successfully!!");
              },
            ),
            ListTile(
              leading: Icon(Icons.logout),
              title: Text("Logout"),
              onTap: () async {
                await FirebaseAuth.instance.signOut();
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginPage()),
                );
              },
            ),
          ],
        ),
      ),
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.delivery_dining, color: Colors.white),
            SizedBox(width: 10),
            Flexible(
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(
                  "NTU Instant Delivery",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.chat),
            onPressed: () {
              if (chatRoom != null) {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ChatRoomPage(
                      userModel: widget.userModel,
                      targetUser: widget.userModel,
                      chatRoom: chatRoom!,
                      firebaseuser: widget.firebaseuser,
                    ),
                  ),
                );
              } else {
                UIHelper.ShowSnackBar(context, "No chat room found.");
              }
            },
          ),
        ],
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          return SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              elevation: 10,
              shadowColor: Theme.of(context).primaryColor.withOpacity(0.3),
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Form(
                  key: _formKey,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  child: Column(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(80),
                        child: Container(
                          color: Colors.green,
                          child: Image.asset(
                            "assets/images/ntuapplogo.png",
                            height: 150,
                            fit: BoxFit.contain,
                            color: Colors.white,
                            colorBlendMode: BlendMode.srcATop,
                          ),
                        ),
                      ),
                      SizedBox(height: 15),
                      TextFormField(
                        controller: _nameController,
                        decoration: InputDecoration(labelText: "Enter your phone"),
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'Please enter your name';
                          }
                          return null;
                        },
                      ),
                      SizedBox(height: 20),
                      TextFormField(
                        controller: _locationController,
                        decoration: InputDecoration(labelText: "Enter your location"),
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'Please enter your location';
                          }
                          return null;
                        },
                      ),
                      SizedBox(height: 20),
                      TextFormField(
                        controller: _orderController,
                        maxLines: null,
                        decoration: InputDecoration(labelText: "Order details"),
                        validator: (value) {
                          if (value!.isEmpty) {
                            return 'Please enter order details';
                          }
                          return null;
                        },
                      ),
                      SizedBox(height: 30),
                      ElevatedButton(
                        onPressed: _sendOrderAndNavigateToChat,
                        style: ElevatedButton.styleFrom(
                          minimumSize: Size(double.infinity, 50),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: Text(
                          "Place Your Order",
                          style: TextStyle(fontSize: 18),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
