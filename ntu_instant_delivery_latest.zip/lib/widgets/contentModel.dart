class onboardingContent {
  String image;
  String title;
  String description;

  onboardingContent(
      {required this.title, required this.image, required this.description});
}
