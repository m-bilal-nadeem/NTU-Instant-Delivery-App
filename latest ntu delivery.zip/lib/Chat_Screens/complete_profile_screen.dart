import 'dart:io';
import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:ntu_instant_delievery/Agroover%20screens/orderPage.dart';
import 'package:ntu_instant_delievery/Models/ChatRoomModel.dart';
import 'package:ntu_instant_delievery/Models/UserModel.dart';
import 'package:ntu_instant_delievery/widgets/UIHelper.dart';

class CompleteProfile extends StatefulWidget {
  final UserModel userModel;
  final User firebaseuser;

  const CompleteProfile({
    Key? key,
    required this.userModel,
    required this.firebaseuser,
  }) : super(key: key);

  @override
  State<CompleteProfile> createState() => _CompleteProfileState();
}

class _CompleteProfileState extends State<CompleteProfile> {
  TextEditingController fullnamecontroller = TextEditingController();

  File? imageFile;

  void showPhotooptions() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text("Upload Profile Picture"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                title: Text("Select from Galary"),
                leading: Icon(Icons.photo_album),
                onTap: () {
                  Navigator.pop(context);
                  selectImage(ImageSource.gallery);
                },
              ),
              ListTile(
                title: Text("Take a Photo"),
                leading: Icon(Icons.camera_alt_outlined),
                onTap: () {
                  Navigator.pop(context);
                  selectImage(ImageSource.camera);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  void selectImage(ImageSource source) async {
    XFile? pickedFile = await ImagePicker().pickImage(source: source);

    if (pickedFile != null) {
      cropImage(pickedFile);
    }
  }

  void cropImage(XFile file) async {
    CroppedFile? croppedImage = await ImageCropper().cropImage(
      sourcePath: file.path,
      compressQuality: 30,
      aspectRatio: CropAspectRatio(ratioX: 1, ratioY: 1),
    );

    if (croppedImage != null) {
      setState(() {
        imageFile = File(croppedImage.path);
      });
    }
  }

  void checkValues() {
    String fullname = fullnamecontroller.text.trim();

    if (fullname == "" || imageFile == null) {
      setState(() {
        showDialog(
          context: context,
          builder:
              (context) => AlertDialog(
                title: Text("An Error Occured"),
                content:
                    (fullname == null)
                        ? Text("Enter Full Name First!!")
                        : Text("Upload Profile Picture First!!"),
              ),
        );
      });
    } else {
      uploadData();
    }
  }

  void uploadData() async {
    UploadTask? uploadTask;
    try {
      if (imageFile != null) {
        uploadTask = FirebaseStorage.instance
            .ref("profilepictures")
            .child(widget.userModel.uid.toString())
            .putFile(imageFile!);
      }
    } on FirebaseAuthException catch (ex) {
      print(ex.code.toString());
    }

    TaskSnapshot? snapshot;
    String imageUrl;
    String fullname = fullnamecontroller.text.trim();
    if (fullname != "" && uploadTask != null) {
      snapshot = await uploadTask;
      imageUrl = await snapshot.ref.getDownloadURL();
      fullname = fullnamecontroller.text.trim();

      widget.userModel.fullname = fullname;
      widget.userModel.profilepic = imageUrl;

      UIHelper.showLoadingDialog(context, "Setting Up Account....");
      await FirebaseFirestore.instance
          .collection("users")
          .doc(widget.userModel.uid)
          .set(widget.userModel.toMap());

      print("Data Uploaded Successfully!!");
      
      Navigator.popUntil(context, (route) => route.isFirst);
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder:
              (context) => OrderPage(
                firebaseuser: widget.firebaseuser,
                userModel: widget.userModel,
              ),
        ),
      );
    } else {
      showDialog(
        context: context,
        builder:
            (context) => AlertDialog(
              title: Text("An Error Occured"),
              content:
                  (fullname == "")
                      ? Text("Enter Full Name First!!")
                      : Text("Upload Profile Picture First!!"),
            ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("MBN Profile Page"),
        centerTitle: true,
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: SafeArea(
          child: Container(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CupertinoButton(
                  child: CircleAvatar(
                    backgroundColor: Colors.blue,
                    backgroundImage:
                        (imageFile != null) ? FileImage(imageFile!) : null,
                    child:
                        (imageFile == null)
                            ? Icon(
                              Icons.account_circle,
                              color: Colors.white,
                              size: 50,
                            )
                            : null,
                    radius: 50.0,
                  ),
                  onPressed: () {
                    showPhotooptions();
                  },
                ),
                SizedBox(height: 20),
                TextField(
                  controller: fullnamecontroller,
                  decoration: InputDecoration(
                    hintText: "Full Name",
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(15)),
                    ),
                  ),
                ),
                SizedBox(height: 20),
                CupertinoButton(
                  child: Text("Submit"),
                  color: Colors.blue,
                  onPressed: () {
                    checkValues();

                    uploadData();
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
