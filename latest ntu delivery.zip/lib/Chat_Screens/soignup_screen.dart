import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:ntu_instant_delievery/Chat_Screens/complete_profile_screen.dart';
import 'package:ntu_instant_delievery/Models/UserModel.dart';
import 'package:ntu_instant_delievery/widgets/UIHelper.dart';

class Signup extends StatefulWidget {
  @override
  State<Signup> createState() => _MyWidgetState();
}

class _MyWidgetState extends State<Signup> {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController cPasswordController = TextEditingController();

  void signup() async {
    String email = emailController.text.trim();
    String password = passwordController.text.trim();
    String cPassword = cPasswordController.text.trim();

    if (email == "" || password == "" || cPassword == "") {
      UIHelper.errordialoag(
          context, "Incomplete Data" + "Please fill all the fields");
    } else if (password != cPassword) {
      UIHelper.errordialoag(context,
          "Password Mismatch" + "The passwords you entered do not match!");
    } else {
      try {
        UserCredential credential = await FirebaseAuth.instance
            .createUserWithEmailAndPassword(email: email, password: password);

        if (credential != null) {
          UIHelper.showLoadingDialog(context, "Creating Account....");
          String uid = credential.user!.uid;
          UserModel newUser = UserModel(uid, "", email, "");
          await FirebaseFirestore.instance
              .collection("users")
              .doc(uid)
              .set(newUser.toMap());
          Navigator.popUntil(context, (route) => route.isFirst);
          print("New User Created");
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => CompleteProfile(
                  firebaseuser: credential.user!,
                  userModel: newUser,
                ),
              ));
        }
      } on FirebaseAuthException catch (ex) {
        print(ex.code.toString());
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus,
        child: SafeArea(
          child: Container(
            padding: EdgeInsets.symmetric(
              horizontal: 40,
            ),
            child: Center(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Text(
                      "Chat App",
                      style: TextStyle(
                          color: Colors.blue,
                          fontSize: 45,
                          fontWeight: FontWeight.bold),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    TextField(
                      controller: emailController,
                      decoration: InputDecoration(labelText: "Email Address"),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    TextField(
                      controller: passwordController,
                      obscureText: true,
                      decoration: InputDecoration(labelText: "Password"),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    TextField(
                      controller: cPasswordController,
                      obscureText: true,
                      decoration:
                          InputDecoration(labelText: "Confirm Password"),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    CupertinoButton(
                      onPressed: () {
                        signup();
                      },
                      color: Colors.blue,
                      child: Text("Sign Up"),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: Container(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Already have an account?",
              style: TextStyle(fontSize: 16),
            ),
            CupertinoButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text(
                "Log In",
                style: TextStyle(fontSize: 16, color: Colors.blue),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
