package com.example.ntu_instant_delievery

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
