import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'package:ntu_instant_delievery/Agroover screens/Admin.dart';
import 'package:ntu_instant_delievery/Models/UserModel.dart';
import 'package:ntu_instant_delievery/widgets/UIHelper.dart';
import 'package:ntu_instant_delievery/Agroover screens/orderPage.dart';
import 'package:ntu_instant_delievery/Chat_Screens/soignup_screen.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  void login() async {
    String email = emailController.text.trim();
    String password = passwordController.text.trim();

    if (email.isEmpty || password.isEmpty) {
      UIHelper.errordialoag(context, "Please fill all the fields!");
    } else {
      try {
        UIHelper.showLoadingDialog(context, "Logging in...");

        UserCredential credential = await FirebaseAuth.instance
            .signInWithEmailAndPassword(email: email, password: password);

        if (credential.user != null) {
          String uid = credential.user!.uid;

          DocumentSnapshot userdata =
              await FirebaseFirestore.instance
                  .collection("users")
                  .doc(uid)
                  .get();

          if (userdata.exists) {
            UserModel userModel = UserModel.fromMap(
              userdata.data() as Map<String, dynamic>,
            );

            Navigator.popUntil(context, (route) => route.isFirst);

            if (email == "bilalnadeem2005kb@gmail.com") {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder:
                      (context) => AdminPage(
                        userModel: userModel,
                        firebaseUser: credential.user!,
                      ),
                ),
              );
            } else {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(
                  builder:
                      (context) => OrderPage(
                        userModel: userModel,
                        firebaseuser: credential.user!,
                      ),
                ),
              );
            }
          } else {
            Navigator.pop(context); // Close loading dialog
            UIHelper.errordialoag(context, "User Data Doesn't Exist!");
          }
        }
      } on FirebaseAuthException catch (ex) {
        Navigator.pop(context); // Close loading dialog
        UIHelper.errordialoag(context, ex.message.toString());
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GestureDetector(
        onTap: () => FocusScope.of(context).unfocus(),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Center(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Text(
                      "Chat App",
                      style: TextStyle(
                        color: Colors.blue,
                        fontSize: 45,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 10),
                    TextField(
                      controller: emailController,
                      decoration: InputDecoration(labelText: "Email Address"),
                    ),
                    SizedBox(height: 10),
                    TextField(
                      controller: passwordController,
                      obscureText: true,
                      decoration: InputDecoration(labelText: "Password"),
                    ),
                    SizedBox(height: 20),
                    CupertinoButton(
                      onPressed: login,
                      color: Colors.blue,
                      child: const Text("Log In"),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text("Don't have an account?", style: TextStyle(fontSize: 16)),
          CupertinoButton(
            onPressed: () {
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => Signup()),
              );
            },
            child: Text(
              "Sign Up",
              style: TextStyle(fontSize: 16, color: Colors.blue),
            ),
          ),
        ],
      ),
    );
  }
}
