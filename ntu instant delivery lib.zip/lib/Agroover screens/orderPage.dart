import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../widgets/UIHelper.dart';
import 'About.dart';
import 'Login_Screen.dart';
import 'Terms.dart';
import 'modeSelectionScreen.dart';

class OrderPage extends StatefulWidget {
  final bool isGuest;  // New parameter to track guest status

  const OrderPage({Key? key,this.isGuest = false}) : super(key: key);

  @override
  _OrderPageState createState() => _OrderPageState();
}

class _OrderPageState extends State<OrderPage> {
  final _nameController = TextEditingController();
  final _orderController = TextEditingController();
  final _locationController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  final String vendorNumber = "+923114594563";

  

  void _openWhatsApp() async {
    if (!_formKey.currentState!.validate()) return;

    final message = '''
👋 *Hi there!* 

🧍‍♂️ *Name:* ${_nameController.text.trim()}
📍 *Location:* ${_locationController.text.trim()}
🛒 *Order Details:* ${_orderController.text.trim()}

❓Can you deliver this to my location?

Thanks! 😊
''';

    final String phone = vendorNumber.replaceAll('+', '');

    final Uri whatsappUrl = Uri.parse(
      "https://wa.me/$phone?text=${Uri.encodeFull(message)}",
    );

    final Uri whatsappIntent = Uri.parse(
      "intent://send?phone=$phone&text=${Uri.encodeFull(message)}#Intent;package=com.whatsapp;scheme=smsto;end",
    );

    try {
      if (await canLaunchUrl(whatsappUrl)) {
        await launchUrl(whatsappUrl, mode: LaunchMode.externalApplication);
      } else if (await canLaunchUrl(whatsappIntent)) {
        await launchUrl(whatsappIntent, mode: LaunchMode.externalApplication);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Could not launch WhatsApp")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error launching WhatsApp: $e")),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isSmallScreen = screenWidth < 360;

    return Scaffold(
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.green,
              ),
              child: FutureBuilder<User?>(
                future: Future.value(FirebaseAuth.instance.currentUser),
                builder: (context, snapshot) {
                  final user = snapshot.data;

                  return Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      CircleAvatar(
                        radius: 30,
                        backgroundColor: Colors.white,
                        backgroundImage: user?.photoURL != null
                            ? NetworkImage(user!.photoURL!)
                            : null,
                        child: user?.photoURL == null
                            ? Icon(Icons.person, size: 35, color: Colors.green)
                            : null,
                      ),
                      SizedBox(height: 12),
                      Text(
                        user != null
                            ? (user.displayName ?? "NTU User")
                            : "NTU Delivery Menu",  // Show "NTU Delivery Menu" for guest
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                      if (user != null && user.email != null)
                        Text(
                          user.email!,
                          style: TextStyle(
                            fontSize: 13,
                            color: Colors.white70,
                          ),
                        ),
                      if (widget.isGuest)  // Show login button for guest
                        Padding(
                          padding: const EdgeInsets.only(top: 10),
                          child: TextButton(
                            onPressed: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (_) => LoginScreen(themeisDark: false)),
                              );
                            },
                            child: Text(
                              "Login / Sign Up",
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        ),
                    ],
                  );
                },
              ),
            ),
            ListTile(
              leading: Icon(Icons.info_outline),
              title: Text("About"),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => AboutUsPage(isDarkTheme: false)));
              },
            ),
            ListTile(
              leading: Icon(Icons.library_books),
              title: Text("Terms & Conditions"),
              onTap: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => TermsPage(isDarkTheme: false)));
              },
            ),
            ListTile(
              leading: Icon(Icons.login),
              title: Text("Login another account"),
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => LoginScreen(themeisDark: false)));
              },
            ),

            ListTile(
              leading: Icon(Icons.refresh),
              title: Text("Refresh App"),
              onTap: () {
                _formKey.currentState?.reset();
                _nameController.clear();
                _orderController.clear();
                _locationController.clear();
                Navigator.pop(context);
                UIHelper.ShowSnackBar(context, "App Refreshed Successfully!!");
              },
            ),



            ListTile(
              leading: Icon(Icons.logout),
              title: Text("Logout"),
              onTap: () async {
                await FirebaseAuth.instance.signOut();
                Navigator.pushReplacement(context,
                    MaterialPageRoute(builder: (context) => ModeSelectionScreen()));
              },
            ),
          ],
        ),
      ),
      appBar: AppBar(
        title: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.delivery_dining, color: Colors.white),
            SizedBox(width: 10),
            Flexible(
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(
                  "NTU Instant Delivery",
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
        centerTitle: true,
        actions: [
          SizedBox(width: 10),
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: TextButton(
              onPressed: () async {
                // Example logout function
                await FirebaseAuth.instance.signOut();
                UIHelper.ShowSnackBar(context, "Logged Out Successfully!");
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => ModeSelectionScreen()));
              },
              child: Icon(Icons.login_outlined,
                  size: MediaQuery.of(context).size.width * 0.06,
                  color: Colors.white),
            ),
          ),
        ],
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          return SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
              ),
              elevation: 10,
              shadowColor: Theme.of(context).primaryColor.withOpacity(0.3),
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Form(
                  key: _formKey,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  child: Column(
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(80),
                        child: Container(
                          color: Colors.green,
                          child: Image.asset(
                            "assets/images/ntuapplogo.png",
                            height: 150,
                            fit: BoxFit.contain,
                            color: Colors.white,
                            colorBlendMode: BlendMode.srcATop,
                          ),
                        ),
                      ),
                      SizedBox(height: 20),
                      Text(
                        "Place Your Order",
                        style: TextStyle(
                          fontStyle: FontStyle.italic,
                          fontSize: constraints.maxWidth < 400 ? 20 : 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.green,
                        ),
                      ),
                      SizedBox(height: 20),
                      TextFormField(
                        controller: _nameController,
                        decoration: InputDecoration(
                          labelText: "Your Name",
                          labelStyle: TextStyle(fontStyle: FontStyle.italic),
                          prefixIcon: Icon(Icons.person),
                        ),
                        validator: (value) => value == null || value.trim().isEmpty
                            ? "*Please enter your name"
                            : null,
                      ),
                      SizedBox(height: 15),
                      TextFormField(
                        controller: _orderController,
                        decoration: InputDecoration(
                          labelStyle: TextStyle(fontStyle: FontStyle.italic),
                          labelText: "What do you want to order?",
                          prefixIcon: Icon(Icons.inventory_2_rounded),
                        ),
                        maxLines: 3,
                        validator: (value) => value == null || value.trim().isEmpty
                            ? "Please enter order details"
                            : null,
                      ),
                      SizedBox(height: 15),
                      TextFormField(
                        controller: _locationController,
                        decoration: InputDecoration(
                          labelStyle: TextStyle(fontStyle: FontStyle.italic),
                          labelText: "Your Location (Slide, Block, etc.)",
                          prefixIcon: Icon(Icons.location_on),
                        ),
                        validator: (value) => value == null || value.trim().isEmpty
                            ? "*Please enter your location"
                            : null,
                      ),
                      SizedBox(height: 40),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(41),
                        child: SizedBox(
                          width: 300,
                          height: 55,
                          child: ElevatedButton.icon(
                            icon: Icon(Icons.send),
                            label: Text(
                              "Send Order via WhatsApp",
                              style: TextStyle(fontSize: 16, fontStyle: FontStyle.italic),
                            ),
                            onPressed: _openWhatsApp,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
